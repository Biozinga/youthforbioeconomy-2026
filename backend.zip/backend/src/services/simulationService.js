class SimulationService {
  /**
   * Moteur Principal (Formules Agronomiques)
   * Calcule les indicateurs à partir d'une surface et d'un type de culture.
   * @param {number} surfaceHectares - La surface S en hectares
   * @param {string} cultureType - 'mais' ou 'ble'
   * @returns {Object} Les indicateurs calculés
   */
  simulate(surfaceHectares, cultureType) {
    if (!surfaceHectares || surfaceHectares <= 0) {
      throw new Error("La surface doit être supérieure à 0.");
    }

    const typeLower = cultureType.toLowerCase();
    if (!['mais', 'ble'].includes(typeLower)) {
      throw new Error("Le type de culture doit être 'mais' ou 'ble'.");
    }

    // Paramètres
    const rendement = typeLower === 'mais' ? 2500 : 1200; // R_residus (kg/ha)
    const efficaciteCollecte = 0.8; // η_collecte
    const fcr = 5; // FCR (Feed Conversion Ratio)
    const tau = 0.33; // τ (Taux de conversion larves -> protéines)

    // Calculs
    // 1. Déchets (kg) = Surface * Rendement * Efficacité
    const dechetsKg = surfaceHectares * rendement * efficaciteCollecte;

    // 2. Larves (kg) = Déchets / FCR
    const larvesKg = dechetsKg / fcr;

    // 3. Protéines (P_insecte) = Larves * τ
    const proteinesKg = larvesKg * tau;

    // 4. Poulets nourris = 1 poulet nécessite 5 kg de protéines
    const pouletsNourris = Math.floor(proteinesKg / 5);

    // 5. CO2 Évité = 4 kg CO2 par kg de protéine
    const co2EviteKg = proteinesKg * 4;

    // Phrase de synthèse
    const phrase = `Avec ${surfaceHectares} hectares de ${cultureType}, TerraLoop génère ${dechetsKg.toFixed(2)} kg de déchets, ${larvesKg.toFixed(2)} kg de larves, ${proteinesKg.toFixed(2)} kg de protéines, nourrit ${pouletsNourris} poulets et évite ${co2EviteKg.toFixed(2)} kg de CO2.`;

    return {
      parametres: {
        surfaceHectares,
        cultureType,
        rendement,
        efficaciteCollecte,
        fcr,
        tau
      },
      resultats: {
        dechetsKg,
        larvesKg,
        proteinesKg,
        pouletsNourris,
        co2EviteKg,
        phrase
      }
    };
  }
}

module.exports = new SimulationService();
