const db = require('../config/db');
const simulationService = require('./simulationService');

class WorkflowService {
  /**
   * Crée une culture et déclenche la génération automatique de déchets et proposition de vente.
   * @param {number} terrainId 
   * @param {string} typeCulture 
   * @param {number} surface 
   */
  async createCultureWorkflow(terrainId, typeCulture, surface) {
    const client = await db.getClient();
    try {
      await client.query('BEGIN');

      // 1. Vérification de la surface du terrain
      const terrainQuery = await client.query('SELECT agriculteur_id, taille_hectares FROM terrain WHERE id = $1', [terrainId]);
      if (terrainQuery.rows.length === 0) throw new Error("Terrain introuvable");
      const tailleMax = parseFloat(terrainQuery.rows[0].taille_hectares);
      const agriculteurId = terrainQuery.rows[0].agriculteur_id;

      const culturesQuery = await client.query('SELECT SUM(surface_utilisee) as total FROM culture WHERE terrain_id = $1', [terrainId]);
      const totalActuel = parseFloat(culturesQuery.rows[0].total || 0);

      if (totalActuel + surface > tailleMax) {
        throw new Error(`Dépassement de capacité : La somme des cultures (${totalActuel + surface} ha) dépasse la taille du terrain (${tailleMax} ha)`);
      }

      // 2. Insertion de la culture
      const cultureInsert = await client.query(
        'INSERT INTO culture (terrain_id, type, surface_utilisee) VALUES ($1, $2, $3) RETURNING id',
        [terrainId, typeCulture, surface]
      );
      const cultureId = cultureInsert.rows[0].id;

      // 3. Calcul automatique des déchets (en utilisant la simulation)
      const simulation = simulationService.simulate(surface, typeCulture);
      const dechetsKg = simulation.resultats.dechetsKg;

      // 4. Création des déchets
      const dechetInsert = await client.query(
        'INSERT INTO dechet (culture_id, quantite_kg) VALUES ($1, $2) RETURNING id',
        [cultureId, dechetsKg]
      );
      const dechetId = dechetInsert.rows[0].id;

      // 5. Génération automatique de la proposition de vente
      // Prix fixé arbitrairement pour la simulation (ex: 0.20 / kg)
      const prix = dechetsKg * 0.20;
      await client.query(
        `INSERT INTO vente_dechet (dechet_id, agriculteur_id, prix, statut) 
         VALUES ($1, $2, $3, 'en_attente')`,
        [dechetId, agriculteurId, prix]
      );

      await client.query('COMMIT');
      return { success: true, message: "Culture et déchets générés avec succès", simulation: simulation.resultats };
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  /**
   * Simule l'acceptation d'une vente et déclenche la suite de la chaîne de valeur
   * Déchets -> Larves -> Poulets -> Fientes -> Engrais -> Vente Engrais
   */
  async processTransformationWorkflow(venteDechetId, poulaillerId) {
    const client = await db.getClient();
    try {
      await client.query('BEGIN');

      // 1. Marquer la vente comme acceptée
      const venteQuery = await client.query(
        "UPDATE vente_dechet SET statut = 'accepte' WHERE id = $1 RETURNING dechet_id, agriculteur_id",
        [venteDechetId]
      );
      if (venteQuery.rows.length === 0) throw new Error("Vente introuvable");
      const { dechet_id, agriculteur_id } = venteQuery.rows[0];

      // 2. Récupérer la quantité de déchets
      const dechetQuery = await client.query('SELECT quantite_kg FROM dechet WHERE id = $1', [dechet_id]);
      const dechetKg = parseFloat(dechetQuery.rows[0].quantite_kg);

      // 3. Transformation en larves (Ratio: 5kg dechet = 1kg larves)
      const larvesKg = dechetKg / 5;
      const larveInsert = await client.query(
        'INSERT INTO larve (dechet_id, quantite) VALUES ($1, $2) RETURNING id',
        [dechet_id, larvesKg]
      );
      const larveId = larveInsert.rows[0].id;

      if (poulaillerId) {
        // 4. Alimentation des poulets
        await client.query(
          'INSERT INTO alimentation (larve_id, poulailler_id, quantite) VALUES ($1, $2, $3)',
          [larveId, poulaillerId, larvesKg]
        );

        // 5. Production de fientes (Exemple Ratio : 1 kg larve = 0.8 kg fiente)
        const fientesKg = larvesKg * 0.8;
        const fienteInsert = await client.query(
          'INSERT INTO fiente (poulailler_id, quantite) VALUES ($1, $2) RETURNING id',
          [poulaillerId, fientesKg]
        );
        const fienteId = fienteInsert.rows[0].id;

        // 6. Transformation en engrais (Exemple Ratio: 1 kg fiente = 0.5 kg engrais)
        const engraisKg = fientesKg * 0.5;
        const engraisInsert = await client.query(
          'INSERT INTO engrais (fiente_id, quantite) VALUES ($1, $2) RETURNING id',
          [fienteId, engraisKg]
        );
        const engraisId = engraisInsert.rows[0].id;

        // 7. Vente d'engrais automatique à l'agriculteur (Retour à la source)
        const prixEngrais = engraisKg * 1.5; // 1.5€ par kg
        await client.query(
          'INSERT INTO vente_engrais (engrais_id, agriculteur_id, prix) VALUES ($1, $2, $3)',
          [engraisId, agriculteur_id, prixEngrais]
        );
      }

      await client.query('COMMIT');
      return { success: true, message: "Transformation en chaîne terminée avec succès." };
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }
}

module.exports = new WorkflowService();
