const simulationService = require('../services/simulationService');

exports.simulate = (req, res) => {
  try {
    const { surface, cultureType } = req.body;

    if (!surface || !cultureType) {
      return res.status(400).json({ error: "Veuillez fournir 'surface' et 'cultureType'." });
    }

    const resultat = simulationService.simulate(parseFloat(surface), cultureType);
    
    return res.status(200).json(resultat);
  } catch (error) {
    return res.status(400).json({ error: error.message });
  }
};
