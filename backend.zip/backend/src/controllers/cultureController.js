const workflowService = require('../services/workflowService');

exports.createCulture = async (req, res) => {
  try {
    const { terrainId, typeCulture, surface } = req.body;

    if (!terrainId || !typeCulture || !surface) {
      return res.status(400).json({ error: "Veuillez fournir terrainId, typeCulture et surface." });
    }

    const resultat = await workflowService.createCultureWorkflow(
      parseInt(terrainId), 
      typeCulture, 
      parseFloat(surface)
    );

    return res.status(201).json(resultat);
  } catch (error) {
    // Différencier une erreur métier (Dépassement de capacité) d'une erreur serveur
    if (error.message.includes('Dépassement') || error.message.includes('introuvable')) {
      return res.status(400).json({ error: error.message });
    }
    console.error(error);
    return res.status(500).json({ error: "Erreur serveur lors de la création de la culture." });
  }
};

exports.processVente = async (req, res) => {
  try {
    const { venteDechetId, poulaillerId } = req.body;

    if (!venteDechetId || !poulaillerId) {
      return res.status(400).json({ error: "Veuillez fournir venteDechetId et poulaillerId." });
    }

    const resultat = await workflowService.processTransformationWorkflow(
      parseInt(venteDechetId), 
      parseInt(poulaillerId)
    );

    return res.status(200).json(resultat);
  } catch (error) {
    console.error(error);
    return res.status(400).json({ error: error.message });
  }
};
