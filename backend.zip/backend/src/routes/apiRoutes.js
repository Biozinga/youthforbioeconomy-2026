const express = require('express');
const router = express.Router();

const simulationController = require('../controllers/simulationController');
const cultureController = require('../controllers/cultureController');

// Route Moteur Principal : Simulateur
router.post('/simulateur', simulationController.simulate);

// Route Workflow : Création de la culture (déclenche déchets et proposition vente)
router.post('/cultures', cultureController.createCulture);

// Route Workflow : Acceptation de la vente (déclenche larves -> poulets -> engrais)
router.post('/ventes/accepter', cultureController.processVente);

module.exports = router;
